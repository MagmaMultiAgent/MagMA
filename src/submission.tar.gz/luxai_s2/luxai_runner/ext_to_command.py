ext_to_command = {
    ".js": "node",
    ".py": "python",
    ".out": "./",
    ".exe": "./",
    ".java": "java",
}
